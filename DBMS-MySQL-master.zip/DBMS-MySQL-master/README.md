# DBMS - SQL

- Content related to Database Management Systems and Structured Query Language
- Contains Query question sheet along with corresponding SQL queries.
- Tested in MySQL package in XAMPP, MySQL Workbench.
