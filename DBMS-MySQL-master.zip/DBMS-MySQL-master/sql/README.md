## Experiment and Solution sets

- **.pdf** files contain problem statements.
- Corresponding numbered **.md** files contain solution SQL queries.
- To be used for sharpening basic SQL skills of course DBMS.
